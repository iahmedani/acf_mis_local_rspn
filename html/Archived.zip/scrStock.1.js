module.exports.stockDist = function () {
  
}